#ifndef __uart_enum_H_
#define __uart_enum_H_

#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"

typedef enum
{
  USART3_NO_cmd,
  USART3_CMD_RECEIVED,

} USART3_cmd_StatusType;

#define MAX_BUFFER_LENGTH                     ((uint8_t) 150u)

void USART3_Init(void);
void USART3_Enable(void);
void NVIC_Int(void);
void USART3_IRQ_Callback(void);
void strTransmit(const char data);
#endif
