


#include <stddef.h>
#include "uart.h"


static uint8_t Data_cnt=0;//RX counter
uint8_t RxBuffer[MAX_BUFFER_LENGTH + 1];
static char RxChar = 0;
USART3_cmd_StatusType current_cmd_Status = USART3_NO_cmd;//cmd receiving status


void strTransmit(const char data)
{
	// Write data into transmit data register
	USART3->DR = data;
	      //to ensure that byte has sent successfully
	while(!(USART3->SR & USART_SR_TXE))
	{
	    //Wait for transmission buffer empty flag
	}

}


void USART3_IRQ_Callback(void)
{
	/* check idle line, the end of receiving ccondition */
	if((USART3->SR & USART_SR_IDLE) == USART_SR_IDLE)
    { 
		/* Read data register to clear idle line flag "cmd receiving has finished "*/
		(void)USART3->DR;
		//end of rx buffer
		RxBuffer[Data_cnt]=0;
		// perfofm access to USART3->DR< ARCH DEPEN>
		Data_cnt=USART3->DR;
		Data_cnt=0;//clean rx counter to receive new cmd
		// set led and Set CMD status
		GPIO_SetBits(GPIOD,GPIO_Pin_12);
		//set current_cmd_Status indicating a new string has been recieved
		current_cmd_Status = USART3_CMD_RECEIVED;
		return;
         
	}
    /* Check USART receiver */
    if((USART3->SR & USART_SR_RXNE) == USART_SR_RXNE)
	{
    	// Read character
		RxChar = USART3->DR;
        //FILL RECIVER BUFFER
        RxBuffer[Data_cnt++]=RxChar;
    }
    else
    {
       //  No new data received
    }
}
void USART3_Init(void)
{
	/* enable RCC */
	RCC->AHB1ENR |= RCC_AHB1ENR_CRCEN;
	/* Enable USART3 clock */
	RCC->APB1ENR = RCC_APB1ENR_USART3EN;
	/* Select oversampling by 8 mode */
	USART3->CR1 &= ~USART_CR1_OVER8;
	/* Select one sample bit method */
	USART3->CR3 |= USART_CR3_ONEBIT;
	/* Select 1 Start bit, 8 Data bits, n Stop bit */
	USART3->CR1 &= ~USART_CR1_M;
	/* Select 1 stop bit */
	USART3->CR2 &= ~USART_CR2_STOP;
	/* disable parity control */
	USART3->CR1 &= ~USART_CR1_PCE;
	  //set baudrate at 38.4kbs ,see page 986 at reference manual
	  /*USARTDIV = Fpclk / (16 * baud_rate)
	     *          = 42000000 / (16 * 38400) = 68.375
	     *
	     * DIV_Fraction = 16 * 0.375 = 0x6
	     * DIV_Mantissa = 68 = 0x44
	     *
	     * BRR          = 0x446 */
	/* Write to USART BRR register */
	USART3->BRR = (uint16_t)0x446;

}


void USART3_Enable(void)
{
	/* Enable USART3 */
	USART3->CR1 |= USART_CR1_UE;
	/* Enable transmitter */
	USART3->CR1 |= USART_CR1_TE;
	/* Enable receiver */
	USART3->CR1 |= USART_CR1_RE;
	/* Enable idle line detection interrupt */
	USART3->CR1 |= USART_CR1_IDLEIE;
	/* Enable reception buffer not empty flag interrupt */
	USART3->CR1 |= USART_CR1_RXNEIE;
}

/* Initialization interrupts conrol unit */
void NVIC_Int(void)
{
	/* Set priority group to 3
	   * bits[3:0] are the sub-priority,
	   * bits[7:4] are the pre-empt priority (0-15) */
	NVIC_SetPriorityGrouping(3);
	NVIC_SetPriority(USART3_IRQn, 1);
	NVIC_EnableIRQ(USART3_IRQn);
}
