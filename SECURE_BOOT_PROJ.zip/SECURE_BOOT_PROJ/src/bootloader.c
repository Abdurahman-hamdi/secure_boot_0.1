
#include <string.h>
#include "bootloader.h"
#include "gpio.h"
#include "stm32f4xx_crc.h"
#include "aes.h"
#include "sha256.h"

extern USART3_cmd_StatusType current_cmd_Status;//CMD received status which is defined in uart.c

/* aes_cbc 128 of(CMD +(ADDR+ADDR_CRC)+(16bytes flash data +CRC))*/
extern uint8_t RxBuffer[MAX_BUFFER_LENGTH + 1];//cmd buffer which is defined in uart.c
static uint8_t RxBuffer_decrypt[MAX_BUFFER_LENGTH + 1]; // hold the message after decryption

/*AES-CBC  decryption private data of 16 bytes blok per every transmmmit */
static uint8_t key[16] = "0123456789abcdef";  // must be used also for encryption at Master side "flasher"
static uint8_t iv[16] =  "abcdef0123456789";  // An Initialization Vector (IV) is a fixed-size input used alongside a secret key in  CBC mode.
static mbedtls_aes_context aes_cbc;
static mbedtls_sha256_context sha_state;

void boot_init(void)
{
	led_init();
	NVIC_Int();
	USART3_GPIO_Config();
	USART3_Init();
	USART3_Enable();
	CRC_ResetDR();//reset crc-unit
	__enable_irq();//enable interrupts which has been disabled by app before sw reset
    mbedtls_aes_init(&aes_cbc);/* AES-CBC decryption init */
    mbedtls_aes_setkey_dec(&aes_cbc, key, 128);  // 128-bit key
    mbedtls_sha256_init(&sha_state);//init sha256
    mbedtls_sha256_starts(&sha_state, 0); //select sha256

}




/**
 * boot_process(): it monitors uart received data to locate them to flash_write, flash_read, or jump to new firmware according the command in RxBuffer_decrypt[0] .
 * boot_process() is called by main function
 */
void boot_process()
{
	
	while(1)
	{
		switch(current_cmd_Status)
		{
	  		case USART3_CMD_RECEIVED:
				// Decrypt the block
    			mbedtls_aes_crypt_cbc(&aes_cbc, MBEDTLS_AES_DECRYPT, 64, iv, (uint8_t*)RxBuffer, (uint8_t*)RxBuffer_decrypt);//decrypt 16 bytes recived flash data
				switch(RxBuffer_decrypt[0])
				{
					case 's': // start session
						current_cmd_Status = USART3_NO_cmd;
						break;
	       			case CMD_ERASE:
						CRC_ResetDR();
						boot_cmdErase(RxBuffer_decrypt);
						CRC_ResetDR();
				 		break;
					case CMD_WRITE:
						CRC_ResetDR();
						boot_cmdWrite(RxBuffer_decrypt);
						CRC_ResetDR();
            			break;
					case CMD_Jump:
				 		CRC_ResetDR();
				 		boot_cmdjump(RxBuffer_decrypt);
				 		CRC_ResetDR();
        	     		break;
					default:
						/* TBD: Invalid command handler */
						break;

		    	}
			case USART3_NO_cmd:
      			GPIO_SetBits(GPIOD,GPIO_Pin_15);
            	GPIO_ResetBits(GPIOD,GPIO_Pin_12);
		    	break;
			default:
				break;

		}

	}

}


/**
 * boot_cmdErase is called by boot_process to erase the flash  memory.
 * It takes and pointer to  RxBuffer_decrypt and gets the id to erase All memory sector, or only one sector.
 * 
 */

void boot_cmdErase(uint8_t *pucData){
	current_cmd_Status = USART3_NO_cmd;
	uint32_t crc_val=0;
	uint32_t pulCmd[] = { pucData[0], pucData[1] };
	memcpy(&crc_val, pucData + 2, sizeof(uint32_t));
	if(crc_val==CRC_CalcBlockCRC(pulCmd, 2))
	{
		FLASH_Unlock();
		if(RxBuffer_decrypt[1]==0xff)
		{	FLASH_EraseAllSectors(VoltageRange_3);
		}
		else
		{	FLASH_EraseSector(RxBuffer[1], VoltageRange_3);
		}
		FLASH_Lock();
    		strTransmit(ACK);
	}
	else
	{

		strTransmit(NACK);
		return;
	}

}


/**
 * boot_cmdWrite is called by boot_process during reflashing to write the image in the memory
 * 
 */
void boot_cmdWrite(uint8_t*pucData)
{
	current_cmd_Status = USART3_NO_cmd;
	uint32_t ulSaddr = 0, ulCrc = 0,val;
	memcpy(&ulSaddr, pucData + 1, sizeof(uint32_t));
	memcpy(&ulCrc, pucData + 5, sizeof(uint32_t));
	uint32_t pulData[5]; 
	uint32_t pullData[16]={0}; 
	for(int i = 0; i < 5; i++)
	pulData[i] = pucData[i];
	val=CRC_CalcBlockCRC(pulData, 5);
	if(ulCrc==val)
	{
    	CRC_ResetDR();
		memset(RxBuffer, 0, 20*sizeof(char));
		strTransmit(ACK);
      	while(current_cmd_Status==USART3_NO_cmd);//wait for the rest of command
       	current_cmd_Status = USART3_NO_cmd;
	    memcpy(&ulCrc, pucData + 16, sizeof(uint32_t));
		for(int i = 0; i < 16; i++)
		{
			pullData[i] = pucData[i];
		}
	    val=CRC_CalcBlockCRC((uint32_t*)pullData, 16);
	    if(ulCrc==val)
		{
			FLASH_Unlock();
			for (uint8_t i = 0; i < 16; i++) 
			{
				FLASH_ProgramByte(ulSaddr,pucData[i]);
				ulSaddr += 1;
			}
			FLASH_Lock();
			strTransmit(ACK);
		}
	    else 
	    {
			strTransmit(NACK);
			return;
        }

	}
	else
	{
		strTransmit(NACK);
		return;

	}

}


/**
 * boot_cmdjump is called by boot_process() after writing the flash memory to start new Application
 * 
 */
void boot_cmdjump(uint8_t*p)
{
	uint32_t crc=0,val=0;
	current_cmd_Status = USART3_NO_cmd;
	memcpy(&crc, p + 5, sizeof(uint32_t));
	uint32_t pulData[5];
	for(int i = 0; i < 5; i++)
	pulData[i] = p[i];
	val=CRC_CalcBlockCRC(pulData, 5);
	if(crc==val)
	{
    	/* Get jump address */
		uint32_t *address = (uint32_t*) *(uint32_t *)(p+1);
		jump_to_new_app(address);
		strTransmit(ACK);
	}
	else
	{
    	strTransmit(NACK);
        return;
	}
}



/* check_imageconsistency read the image sector and calculate the sha256 checksume.

it returns __FAILED if the SHA256 operation word != reserved word at SHA256_word
it returns __SUUCESS if they  are identical.
*/
oper_statues check_imageconsistency(void)
{
	uint8_t shaword[32]={0};
	mbedtls_sha256_update(&sha_state, (const uint8_t *)IMAGE_SADDR, SECTOR_SIZE);
	mbedtls_sha256_finish_ret(&sha_state, shaword);
	mbedtls_sha256_free(&sha_state);
	for(uint8_t cnt=0; cnt<5; cnt++)
	{
		if(shaword[cnt] != *(const uint8_t *)(SHA256_word+cnt))
			return __FAILED;

	}
	return __SUUCESS;
}